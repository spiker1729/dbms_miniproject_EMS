
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <?php
session_start();
//echo " <b>hello ".$_SESSION['user_type'] ;
echo "<center>";
echo "<hr>";
echo"<div style='font-size:1.25em;font-color:#0e3c68'>HELLO : </b>".$_SESSION['user_name']; 

echo "</center>";
echo "<hr>";

$name=$_SESSION['user_name'];
?>
	<?php
if(isset($_POST['logoutButtonName'])) {
  session_destroy();

  header('location:login.php');
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="modify_records.js"></script>
    <title>dummy</title>

    <?php

$conn =mysqli_connect("localhost","root","password","ems") or die("connection failed");

$sql ="select city_name from event_details";

$query =mysqli_query($conn,$sql) or die("query failed");


?>

</head>
<body>
<form action="" method="post">

<br>
<button type="submit" name="logoutButtonName" class="btn btn-primary" style="right">Logout</button>
</from>
    <center>
    <fieldset>
<legend>BOOK TICKET:</legend >
<form style="padding:50px" action="" method="post">
    <center>
    <label >Select  city:</label>
    <select id="city" name ="city">
  <option value="0">Select City</option>
    <?php while ($row = mysqli_fetch_assoc($query)) : ?>
                            <option value="<?php echo $row['city_name']; ?>"> <?php echo $row['city_name']; ?> </option>
                        <?php endwhile; ?>
</select>
<br><br>
<label for="">Category available</label>


    <select id="category" name="category">
        <option value=""></option>
    </select>
    <button type="submit" name="submit" class="button">SEARCH</button>

    </center>

    
<table class="table">
        <thead>
            <tr>
                <th>city_name</th>
                <th>event_category</th>
                <th>event_date</th>
                <th>event_time</th>
				<th>total_seats</th>
                <th>available_seats</th>
                <th>ticket_price</th>
                <th>no of tickets</th>
                
            </tr>
        </thead>

        <tbody>
            <?php   
            if(isset($_POST['submit'])){
                $selected_val = $_POST['category']; 
                $selected_val1 = $_POST['city'];
                 // Storing Selected Value In Variable
                
            
            $severname="localhost";
            $username="root";
            $password="password";
            $database="ems";

            //create connection
            $connection =new mysqli($severname,$username,$password,$database);
            if($connection->connect_error){
                die("connection failed :".$connection->connect_error);
            }

            $sql="select * from event_details where event_category='$selected_val' and city_name='$selected_val1' and  available_seats>0";
           // $sql1="select reg.no from info where reg.no='str'";
            $result =$connection->query($sql);
            
          //  $result1 =$connection->query($sql1);
            if(!$result){
                die("invalid query :".$connection->error);
            }
          

            while($row=$result->fetch_assoc()){
               
                echo"  <tr>
            <td>". $row["city_name"]."</td>
            <td>". $row["event_category"]."</td>
            <td>". $row["event_date"]."</td>
            <td>". $row["event_time"]."</td>
			<td>". $row["total_seats"]."</td>
            <td>". $row["available_seats"]."</td>
            <td>". $row["ticket_price"]."</td>
            
            <td><a href='noof.php?time=".$row['event_time']."'>Book</a></td>
            </tr>";
            }

        }
            ?>
        </tbody>
    </table>
        
    </fieldset>
</form> 
<br><hr><br>

<form action="" method="post">
<center>

<p> booked tickets</p>


</center>
   
<table class="table">
        <thead>
            <tr>
                <th>user_name</th>
                <th>ticket_no</th>
                <th>city name</th>
                <th>event name</th>
				<th>date</th>
                <th>time</th>
                <th>ticket_status</th>
                <th>no of tickets</th>
               
            </tr>
        </thead>

        <tbody>
            <?php   
            if(isset($_POST['submit'])){
                $selected_val = $_POST['category']; 
                $selected_val1 = $_POST['city'];
                 // Storing Selected Value In Variable
                
            
            $severname="localhost";
            $username="root";
            $password="password";
            $database="ems";

            //create connection
            $connection =new mysqli($severname,$username,$password,$database);
            if($connection->connect_error){
                die("connection failed :".$connection->connect_error);
            }
        
            
           
            $sql="select * from ticket_booked where user_name='{$_SESSION['user_name']}'";
           // $sql1="select reg.no from info where reg.no='str'";
            $result =$connection->query($sql);
          //  $result1 =$connection->query($sql1);
            if(!$result){
                die("invalid query :".$connection->error);
            }
          

            while($row=$result->fetch_assoc()){
               
                echo"  <tr>
            <td>". $row["user_name"]."</td>
            <td>". $row["ticket_no"]."</td>
            <td>". $row["city_name"]."</td>
            <td>". $row["event_name"]."</td>
			<td>". $row["date"]."</td>
            <td>". $row["time"]."</td>
            <td>". $row["status"]."</td>
            <td>". $row["no_of_ticket_booked"]."</td>
            </tr>";
            }

        }
            ?>
        </tbody>
    </table>

</form>


<script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>

<script type="text/javascript">
        $('#city').on('change', function(result) {
        var value = this.value;
     //console.log(value);
        $.ajax({
            url: 'dummy2.php',
            type: "POST",
            data: {
               value: value
            },
            success: function(result) {
                $('#category').html(result);
                 console.log(result);
            }
        })
    });


</script>

</body>
</html>