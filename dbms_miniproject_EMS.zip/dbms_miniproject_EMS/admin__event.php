
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
   <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
	<?php
if(isset($_POST['logoutButtonName'])) {
  session_destroy();

  header('location:login.php');
}

?>
   <title>ADMIN</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#" style="margin-left: 50px;" >ADMIN DASHBOARD</a>

  <div >
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="add_event.php"  style="color:red;" class="btn btn-primary">ADD EVENT  <span class="sr-only">        </span></a>
      </li>
      
      <li class="nav-item">
 
    </ul>
 






  </div>
</nav>
<p>
<?php

session_start();
echo "<br>";

echo" <p align='center'> <font color=blue  size='6pt'> HELLO : ".$_SESSION['user_name'];

?>
<form action="" method="post">

<br>
<button type="submit" name="logoutButtonName" class="btn btn-primary" style="right">Logout</button>
</from>

</p>
<hr>
<center><P>Available Events</P></center>
<hr>


<table class="table">
        <thead>
            <tr>
                <th>city_name</th>
                <th>event_category</th>
                <th>event_date</th>
                <th>event_time</th>
				<th>total_seats</th>
                <th>available_seats</th>
                <th>ticket_price</th>
            </tr>
        </thead>

        <tbody>
            <?php   
            $severname="localhost";
            $username="root";
            $password="password";
            $database="ems";

            //create connection
            $connection =new mysqli($severname,$username,$password,$database);
            if($connection->connect_error){
                die("connection failed :".$connection->connect_error);
            }

            $sql="select * from event_details where available_seats>'0'";
           // $sql1="select reg.no from info where reg.no='str'";
            $result =$connection->query($sql);
          //  $result1 =$connection->query($sql1);
            if(!$result){
                die("invalid query :".$connection->error);
            }
          

            while($row=$result->fetch_assoc()){
               
                echo"  <tr>
            <td>". $row["city_name"]."</td>
            <td>". $row["event_category"]."</td>
            <td>". $row["event_date"]."</td>
            <td>". $row["event_time"]."</td>
			<td>". $row["total_seats"]."</td>
            <td>". $row["available_seats"]."</td>
            <td>". $row["ticket_price"]."</td>
            </tr>";
            }

            
            ?>
        </tbody>
    </table>
</body>
</html>