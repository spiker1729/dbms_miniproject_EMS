<?php
$conn = mysqli_connect('localhost','root','password','ems');


$state_id =  $_POST['value'];

$city = "SELECT * FROM event_details WHERE city_name = '$state_id'";
$city_qry = mysqli_query($conn, $city);


$output = '<option value="">Select Category</option>';

while ($city_row = mysqli_fetch_assoc($city_qry)) {
    
    $output .= '<option value="'. $city_row['event_category'].'">' . $city_row['event_category'] . '</option>';
}

echo $output;

$conn->close();